<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDkMVAEsH9Mi-MfOjWX_ELRGKpVQ7wkLHo",
    authDomain: "loan-b47f0.firebaseapp.com",
    projectId: "loan-b47f0",
    storageBucket: "loan-b47f0.appspot.com",
    messagingSenderId: "937902814393",
    appId: "1:937902814393:web:495fbc1dbd6404fd589768",
    measurementId: "G-20XVTBWTZQ"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>