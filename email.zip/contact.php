<!DOCTYPE html>
<?php

    require_once('mailer/class.phpmailer.php');
    require 'mailer/PHPMailerAutoload.php';
    require 'mailer/class.smtp.php';

if(isset($_POST['send']))
{

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $comment = $_POST['comment'];
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->CharSet = "UTF-8";
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com'; // add host name 
    $mail->Port = 465;
    $mail->Username = 'smwebdesigner29@gmail.com'; //user name
    $mail->Password = 'anrvalkclzfkjbsy';
    $mail->SMTPAuth = true;
    $mail->SMTPDebug = 0;  // Set to 0 in production

    $mail->setFrom('samychishty89@gmail.com', 'Demo'); //sender name
    $mail->addAddress("samychishty89@gmail.com");  // Add recipient address
    $mail->addReplyTo($_POST["email"], $_POST["name"]);

    // Other settings remain the same...

    $mail->Subject = "Customer Details";

    $mail->Body = '<p><strong>Name: </strong>' . $name . '</p>
    <p><strong>Phone: </strong>' . $phone . '</p>
    <p><strong>Email: </strong>' . $email . '</p>
    <p><strong>Message: </strong>' . $message . '</p>';

    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

 $mail->send();
    echo
    " 
    <script> 
     alert('Message was sent successfully!');
     document.location.href = 'contact.php';
    </script>
    ";



}
?>

<html lang="en">


<!-- Mirrored from chargey.websitelayout.net/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Jun 2024 13:31:53 GMT -->
<head>

    <!-- metas -->
    <meta charset="utf-8">
    <meta name="author" content="Chitrakoot Web">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="Electric Vehicle Charging Station">
    <meta name="description" content="Chargey - Electric Vehicle Charging Station">

    <!-- title  -->
    <title>Chargey - Electric Vehicle Charging Station</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="img/logos/favicon.png">
    <link rel="apple-touch-icon" href="img/logos/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="72x72" href="img/logos/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="img/logos/apple-touch-icon-114x114.png">

    <!-- plugins -->
    <link rel="stylesheet" href="css/plugins.css">

    <!-- search css -->
    <link rel="stylesheet" href="search/search.css">

    <!-- quform css -->
    <link rel="stylesheet" href="quform/css/base.css">

    <!-- theme core css -->
    <link href="css/styles.css" rel="stylesheet">
    <style>
    [data-overlay-dark]:before {
    background: white;
}
    </style>
</head>

<body>

    <!-- PAGE LOADING
    ================================================== -->
    <div id="preloader"></div>

    <!-- MAIN WRAPPER
    ================================================== -->
    <div class="main-wrapper">

        <!-- HEADER
        ================================================== -->
        <header class="header-style1 menu_area-light">

            <div class="navbar-default border-bottom border-color-light-white">

                <!-- start top search -->
                <div class="top-search bg-primary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="https://chargey.websitelayout.net/search.html" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off" placeholder="Type & hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end top search -->

                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12">
                            <div class="menu_area alt-font">
                                     <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <!-- start logo -->
                                        <a href="index.html" class="navbar-brand"><img id="logo" src="img/logos/logo-inner.png" alt="logo"></a>
                                        <!-- end logo -->
                                    </div>

                                    <div class="navbar-toggler"></div>

                                    <!-- start menu area -->
                                  <ul class="navbar-nav ms-auto" id="nav" style="display: none;">
                                        <li><a href="index.html">Home</a></li>
                                        <li>
                                            <a href="About.html">About Us</a>
                                           <ul>
                                                <li><a href="About.html" style ="background: -webkit-linear-gradient(#377ff6, #e80ddb);-webkit-background-clip: text;-webkit-text-fill-color: transparent;">Core Team</a></li>
                                                <li><a href="About.html" style="background: -webkit-linear-gradient(#377ff6, #e80ddb);-webkit-background-clip: text;-webkit-text-fill-color: transparent;">Vision & Mission</a></li>
                                                <li><a href="About.html" style ="background: -webkit-linear-gradient(#377ff6, #e80ddb);-webkit-background-clip: text;-webkit-text-fill-color: transparent;">Timeline</a></li>
                                               
                                                    </ul>
                                                </li>
                                             
                                        <li>
                                            <a href="Products.html">Products</a>
                                           <!-- <ul>
                                                <li><a href="services.html">Our Services</a></li>
                                                <li><a href="public-stations.html">Public Stations</a></li>
                                                <li><a href="solar-clean-energy.html">Solar & Clean Energy</a></li>
                                                <li><a href="commercial-systems.html">Commercial Systems</a></li>
                                                <li><a href="charge-point-stations.html">Charge Point Stations</a></li>
                                                <li><a href="home-charging.html">Home Charging</a></li>
                                                <li><a href="dc-charger-service.html">DC Charger Service</a></li>
                                                <li><a href="corporate-business.html">Corporate Business</a></li>
                                                <li><a href="hybrid-car-watches.html">Hybrid Car Watches</a></li>
                                            </ul>
                                        </li>-->
                                        <li>
                                            <a href="Services.html">Services</a>
                                           <!-- <ul>
                                                <li><a href="portfolio.html">Portfolio</a></li>
                                                <li><a href="portfolio-details.html">Portfolio Details</a></li>
                                            </ul>
                                        </li>-->
                                        <li>
                                            <a href="Solutions.html">Solutions</a>
                                          <!--  <ul>
                                                <li><a href="blog-grid.html">Blog Grid</a></li>
                                                <li><a href="blog-list.html">Blog List</a></li>
                                                <li><a href="blog-details.html">Blog Details</a></li>
                                            </ul>
                                        </li>-->
                                        <!-- <li>
                                            <a href="#!">Resources</a> -->
                                           <!-- <ul class="row megamenu">
                                                <li class="col-lg-3">
                                                    <span class="mb-0 mb-lg-2 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-700 display-30">Elements 01</span>
                                                    <ul>
                                                        <li><a href="accordion.html"><i class="fas fa-sliders-h me-2"></i>Accordions</a></li>
                                                        <li><a href="alerts.html"><i class="far fa-bell me-2"></i>Alerts</a></li>
                                                        <li><a href="blockquotes.html"><i class="fas fa-vector-square me-2"></i>Blockquote</a></li>
                                                        <li><a href="buttons.html"><i class="fas fa-link me-2"></i>Buttons</a></li>
                                                        <li><a href="call-to-action.html"><i class="far fa-square me-2"></i>Call to Action</a></li>
                                                        <li><a href="carousel-slider.html"><i class="far fa-images me-2"></i>Carousel Slider</a></li>
                                                        <li><a href="count-down.html"><i class="far fa-flag me-2"></i>Count Down</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3">
                                                    <span class="mb-0 mb-lg-2 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-700 display-30">Elements 02</span>
                                                    <ul>
                                                        <li><a href="counter.html"><i class="fas fa-compress me-2"></i>Counters</a></li>
                                                        <li><a href="dropcaps.html"><i class="far fa-closed-captioning me-2"></i>Dropcaps</a></li>
                                                        <li><a href="forms.html"><i class="fab fa-wpforms me-2"></i>Forms</a></li>
                                                        <li><a href="form-elements.html"><i class="fas fa-cubes me-2"></i>Form Elements</a></li>
                                                        <li><a href="font-icons.html"><i class="far fa-check-square me-2"></i>Font Icons</a></li>
                                                        <li><a href="google-map.html"><i class="fas fa-map-marker-alt me-2"></i>Google Map</a></li>
                                                        <li><a href="grid-system.html"><i class="fas fa-th me-2"></i>Grid System</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3">
                                                    <span class="mb-0 mb-lg-2 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-700 display-30">Elements 03</span>
                                                    <ul>
                                                        <li><a href="highlights.html"><i class="fas fa-highlighter me-2"></i>Highlights</a></li>
                                                        <li><a href="header-1.html"><i class="fas fa-compress me-2"></i>Header Style 01</a></li>
                                                        <li><a href="header-2.html"><i class="fas fa-compress-arrows-alt me-2"></i>Header Style 02</a></li>
                                                        <li><a href="icon-with-text.html"><i class="fab fa-fonticons-fi me-2"></i>Icon With Text</a></li>
                                                        <li><a href="list-styles.html"><i class="fas fa-list-ul me-2"></i>List Styles</a></li>
                                                        <li><a href="media-object.html"><i class="fas fa-photo-video me-2"></i>Media Object</a></li>
                                                        <li><a href="modal.html"><i class="fas fa-expand me-2"></i>Modal</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3">
                                                    <span class="mb-0 mb-lg-2 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-700 display-30">Elements 04</span>
                                                    <ul>

                                                        <li><a href="pagination.html"><i class="far fa-caret-square-right me-2"></i>Pagination</a></li>
                                                        <li><a href="progress-bar.html"><i class="fas fa-tasks me-2"></i>Progress Bars</a></li>
                                                        <li><a href="social-icons.html"><i class="fas fa-bezier-curve me-2"></i>Social Icons</a></li>
                                                        <li><a href="tables.html"><i class="fas fa-table me-2"></i>Tables</a></li>
                                                        <li><a href="tabs.html"><i class="fas fa-sliders-h me-2"></i>Tabs</a></li>
                                                        <li><a href="typography.html"><i class="fas fa-text-height me-2"></i>Typography</a></li>
                                                        <li><a href="video.html"><i class="fas fa-video me-2"></i>Videos</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>-->
                                        <li><a href="Contact.html">Contact</a></li>
                                    </ul>
                                    <!-- end menu area -->

                                    <!-- start attribute navigation -->
                                    <!-- <div class="attr-nav align-items-xl-center ms-xl-auto main-font">
                                        <ul>
                                            <li class="search"><a href="#!"><i class="fas fa-search"></i></a></li>
                                            <li class="d-none d-xl-inline-block"><a href="contact.html" class="btn-style1 medium primary">Free Quote</a></li>
                                        </ul>
                                    </div> -->
                                    <!-- end attribute navigation -->
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- PAGE TITLE
        ================================================== -->
        <section class="page-title-section bg-img cover-background top-position1 secondary-overlay overflow-visible" data-overlay-dark="7" data-background="img/banner/contact.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="position-relative text-center">
                            <h1>Contact Us</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-title">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="#!">Contact Us</a></li>
                </ul>
            </div>
        </section>

        <!-- CONTACT FORM
        ================================================== -->
        <section>
            <div class="container">
                <div class="col-lg-8 mx-auto">
                    <div class="shadow p-1-6 p-sm-1-9 p-lg-2-9 border-radius-10">
                        <div class="section-title text-center mb-1-6 mb-md-5">
                            <span>Contact us</span>
                            <h2>Drop Us a Line</h2>
                        </div>
                        <form class="contact quform"  method="post" action="contact.php" enctype="multipart/form-data" onclick="">
                            <div class="quform-elements">
                                <div class="row">

                                    <!-- Begin Text input element -->
                                    <div class="col-md-6">
                                        <div class="quform-element form-group">
                                            <label for="name">Your Name <span class="quform-required">*</span></label>
                                            <div class="quform-input">
                                                <input class="form-control" id="name" type="text" name="name" placeholder="Your name here" />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Text input element -->

                                    <!-- Begin Text input element -->
                                    <div class="col-md-6">
                                        <div class="quform-element form-group">
                                            <label for="email">Your Email <span class="quform-required">*</span></label>
                                            <div class="quform-input">
                                                <input class="form-control" id="email" type="text" name="email" placeholder="Your email here" />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Text input element -->

                                 

                                    <!-- Begin Text input element -->
                                    <div class="col-md-6">
                                        <div class="quform-element form-group">
                                            <label for="phone">Contact Number</label>
                                            <div class="quform-input">
                                                <input class="form-control" id="phone" type="text" name="phone" placeholder="Your phone here" />
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Text input element -->

                                    <!-- Begin Textarea element -->
                                    <div class="col-md-12">
                                        <div class="quform-element form-group">
                                            <label for="message">Message <span class="quform-required">*</span></label>
                                            <div class="quform-input">
                                                <textarea class="form-control" id="message" name="message" rows="3" placeholder="Tell us a few words"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Textarea element -->

                                  

                                    <!-- Begin Submit button -->
                                    <div class="col-md-12">
                                        <div class="quform-submit-inner">
                                            <button class="btn-style1 border-0 medium" type="submit">Send Message</button>
                                        </div>
                                        <div class="quform-loading-wrap text-start"><span class="quform-loading"></span></div>
                                    </div>
                                    <!-- End Submit button -->

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>

        <!-- CONTACT INFO
        ================================================== -->
        <section class="contact-data py-0">
            <div class="container-fuild">
                <div class="row g-md-4">
                    <div class="col-md-6 col-lg-7 col-xl-8 col-xxl-9 order-2 order-md-1">
                        <div class="contact-map">
                            <iframe class="contact-map" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.929457644214!2d72.9490508!3d19.198283199999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b9084a5a12cb%3A0x2b25e557b030e5b1!2sLodha%20Supremus%202%20Tower!5e0!3m2!1sen!2sin!4v1719856408351!5m2!1sen!2sin"></iframe>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5 col-xl-4 col-xxl-3 order-1 order-md-2">
                        <div class="bg-img cover-background contact-inner d-table h-100 w-100" data-overlay-dark="5" >
                            <div class="d-table-cell align-middle h-100">
                                <div class="section-title contact-title mb-1-9 position-relative z-index-9">
                                    <h2 >Sales Office</h2>
                                </div>
                                <div class="d-flex position-relative z-index-9 mb-1-9" style="margin-bottom: 12px;">
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-mobile display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                        <p class="mb-0" style="position: relative;right: 12px;top: 3px;">+91-7738356714</p>
                                   
                                    </div>
                                </div>
                                <div class="d-flex position-relative z-index-9 mb-1-9" style="margin-bottom: 12px;">
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-location-pin display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                        <p class="mb-0 w-sm-40 w-md-100" style="position: relative;right: 12px;top: 3px;">Unit 609, Lodha Supremus I, Road No 22, Wagle Estate Thane West, Maharashtra 425003.</p>
                                    </div>
                                </div>
                                <div class="d-flex position-relative z-index-9" style="margin-bottom: 12px;">
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-email display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                        <p class="mb-0" style="position: relative;right: 12px;top: 3px;">saurabh.r@chhabi-india</p>
                                    
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</br>
<section class="contact-data py-0">
            <div class="container-fuild">
                <div class="row g-md-4">
                    <div class="col-md-6 col-lg-7 col-xl-8 col-xxl-9 order-2 order-md-1">
                        <div class="contact-map">
                            <iframe class="contact-map" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14901.335623926512!2d75.5826491!3d20.9792483!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd90ef3ceb7d0c9%3A0x2d5253cca622362!2sChhabi%20Electricals%20Private%20Limited!5e0!3m2!1sen!2sin!4v1721234530794!5m2!1sen!2sin"></iframe>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5 col-xl-4 col-xxl-3 order-1 order-md-2">
                        <div class="bg-img cover-background contact-inner d-table h-100 w-100" data-overlay-dark="5" >
                            <div class="d-table-cell align-middle h-100" style="margin-bottom: 12px;">
                                <div class="section-title contact-title mb-1-9 position-relative z-index-9">
                                    <h2 >Plant Office</h2>
                                </div>
                                <div class="d-flex position-relative z-index-9 mb-1-9" style="margin-bottom: 12px;">
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-mobile display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                 
                                        <p class="mb-0" style="position: relative;right: 12px;top: 3px;">+91 7400200530</p>
                                    </div>
                                </div>
                                <div class="d-flex position-relative z-index-9 mb-1-9"style="margin-bottom: 12px;"> 
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-location-pin display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                        <p class="mb-0 w-sm-40 w-md-100" style="position: relative;right: 12px;top: 3px;">E66, MIDC Area, Ajantha Road, Jalgaon, Maharashtra 425003</p>
                                    </div>
                                </div>
                                <div class="d-flex position-relative z-index-9" style="margin-bottom: 12px;">
                                    <div class="flex-shrink-0 pt-2">
                                        <i class="ti-email display-20" style="font-size: 22px;"></i>
                                    </div>
                                    <div class="flex-grow-1 ps-4">
                                   
                                        <p class="mb-0" style="position: relative;right: 12px;top: 3px;">shreeraj.n@chhabi-india.com</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</br>
        <!-- FOOTER
        ================================================== -->
        <footer class="position-relative">
            <div class="container">
                <div class="row mt-n1-9">
                    <div class="col-sm-6 col-lg-4 mt-1-9">
                        <div class="pe-sm-5">
                            <div class="section-title footer mb-1-6 mb-md-1-9">
                                <span>About Company</span>
                            </div>
                            <p class="mb-1-9 display-27 text-white opacity9 lh-base">Electric vehicles function by connecting to a charge point and taking power from the grid.</p>
                            <ul class="social-icon-style1">
                                <li>
                                    <a href="#!"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="#!"><i class="fab fa-linkedin-in"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-2 mt-1-9">
                        <div class="ps-sm-5 ps-lg-0">
                            <div class="section-title footer mb-1-6 mb-md-1-9">
                                <span>Quick Links</span>
                            </div>
                            <ul class="list-unstyled mb-0 list-style1">
                                <li><a href="about.html">About</a></li>
                                <li><a href="our-history.html">History</a></li>
                                <li><a href="pricing.html">Pricing</a></li>
                                <li><a href="team.html">Team</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="ps-lg-4 ps-xl-0 pe-sm-1-6 pe-xl-5">
                            <div class="section-title footer mb-1-6 mb-md-1-9">
                                <span>Contacts</span>
                            </div>
                            <ul class="footer-link mb-0 list-unstyled">
                                <li class="text-white mb-4">
                                    <strong>Adress:</strong> <span class="opacity8">66 Guild Street 512B, Great North Town.</span>
                                </li>
                                <li class="text-white mb-4">
                                    <strong>Email:</strong> <span class="opacity8">info@example.com</span>
                                </li>
                                <li class="text-white">
                                    <strong>Phone:</strong> <span class="opacity8">(+44) 123 456 789</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="ps-sm-5 ps-lg-0">
                            <div class="section-title footer mb-1-6 mb-md-1-9">
                                <span>Newsletter</span>
                            </div>
                            <p class="display-28 text-white">Subscribe For The Our Latest Updates !</p>
                            <form class="quform newsletter-form" action="https://chargey.websitelayout.net/quform/newsletter-two.php" method="post" enctype="multipart/form-data" onclick="">

                                <div class="quform-elements">
                                    <div class="row">

                                        <!-- Begin Text input element -->
                                        <div class="col-md-12">
                                            <div class="quform-element mb-0">
                                                <div class="quform-input mb-3">
                                                    <input class="form-control w-70 w-sm-100" id="email_address" type="text" name="email_address" placeholder="Subscribe with us">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End Text input element -->

                                        <!-- Begin Submit button -->
                                        <div class="col-md-12">
                                            <div class="quform-submit-inner">
                                                <button class="btn-style1 primary border-0 w-70 w-sm-100" type="submit">Subscribe</button>
                                            </div>
                                            <div class="quform-loading-wrap"><span class="quform-loading"></span></div>
                                        </div>
                                        <!-- End Submit button -->
                                    </div>

                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-4 border-top border-color-light-white mt-8">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12 text-center">
                            <p class="d-inline-block text-white mb-0">&copy; <span class="current-year"></span> Chargey Powered by <a href="#!" class="text-primary text-white-hover">Chitrakoot Web</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    </div>

    <!-- BUY TEMPLATE
    ================================================== -->
    <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="https://wrapbootstrap.com/theme/chargey-electric-vehicle-charging-station-WB0D7KR16" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

    <div class="all-demo alt-font d-none d-lg-inline-block"><a href="https://www.chitrakootweb.com/contact.html" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>

    <!-- start scroll to top -->
    <a href="#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
    <!-- end scroll to top -->

    <!-- all js include start -->

    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>

    <!-- popper js -->
    <script src="js/popper.min.js"></script>

    <!-- bootstrap -->
    <script src="js/bootstrap.min.js"></script>

    <!-- core.min.js -->
    <script src="js/core.min.js"></script>

    <!-- search -->
    <script src="search/search.js"></script>

    <!-- custom scripts -->
    <script src="js/main.js"></script>

    <!-- form plugins js -->
    <script src="quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="quform/js/scripts.js"></script>

    <!-- all js include end -->
    
</body>


<!-- Mirrored from chargey.websitelayout.net/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 10 Jun 2024 13:32:09 GMT -->
</html>